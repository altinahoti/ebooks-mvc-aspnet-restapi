﻿using eBooks.Models;

namespace eBooks.Data.ViewModels
{
    public class NewBookDropdownsVM

    {

        public NewBookDropdownsVM()
        {
            Producers = new List<Producer>();
            Bookstores= new List<Bookstore>();
            Autors = new List<Autor>();
        }
        public List<Producer> Producers{  get; set; }

        public List<Bookstore> Bookstores { get; set; }

        public List<Autor> Autors { get; set; }
    }
}
