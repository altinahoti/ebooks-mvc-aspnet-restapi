﻿using eBooks.Data.Base;
using eBooks.Data.Enums;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eBooks.Models
{
    public class NewBookVM
    {
        public int Id { get; set; }

        [Display(Name = "Book name")]

        [Required(ErrorMessage ="Name is required")]

        public string Name { get; set; }



        [Display(Name = "Book Description ")]

        [Required(ErrorMessage = "Name is required")]
        public string Description { get; set; }



        [Display(Name = "Price in $")]

        [Required(ErrorMessage = "Price is required")]
        public double Price { get; set; }



        [Display(Name = "Book Photo URL")]

        [Required(ErrorMessage = "Photo URL is required")]
        public string ImageURL { get; set; }





        [Display(Name = "Date Active")]

        [Required(ErrorMessage = "Date is required")]

        public DateTime DateActive { get; set; }





        [Display(Name = "Select a Category")]

        [Required(ErrorMessage = "Books Category is required")]
        public BooksCategory BooksCategory { get; set; }


      
        [Display(Name = "Select Autor (s)")]

        [Required(ErrorMessage = "Autor (s) is required")]
        public List<int> AutorIds { get; set; }
      


        [Display(Name = "Select a Bookstore")]

        [Required(ErrorMessage = "Bookstore is required")]
        public int BookstoreId { get; set; }




        [Display(Name = "Select a Producer")]

        [Required(ErrorMessage = "Book Producer is required")]
     
        public int ProducerId { get; set; }

    }
}
