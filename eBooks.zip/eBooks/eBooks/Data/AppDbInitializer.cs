﻿using eBooks.Data.Enums;
using eBooks.Models;
using Microsoft.AspNetCore.Identity;

namespace eBooks.Data
{
    public class AppDbInitializer
    {
        public static void Seed(IApplicationBuilder applicationBuilder)
        {

            using IServiceScope serviceScope = applicationBuilder.ApplicationServices.CreateScope();
            var context = serviceScope.ServiceProvider.GetService<AppDbContext>();

            context.Database.EnsureCreated();




            //BookStore

            if (!context.Bookstores.Any())
            {
                context.Bookstores.AddRange(new List<Bookstore>()
                    {
                        new Bookstore()
                        {
                            Name = "Libraria Buzuku",
                            PhotoView = "https://lh3.googleusercontent.com/p/AF1QipOioVqR2suEleild0PpeGZ4qEVIhMsgfOabPI2w=w1080-h608-p-no-v0",
                            Description = "Libraria Buzuku gjendet ne Prishtine."
                        },
                         new Bookstore()
                        {
                            Name = "Cinema 2",
                            PhotoView = "http://dotnethow.net/images/cinemas/cinema-2.jpeg",
                            Description = "This is the description of the first cinema"
                        },
                        new Bookstore()
                        {
                            Name = "Cinema 3",
                            PhotoView= "http://dotnethow.net/images/cinemas/cinema-3.jpeg",
                            Description = "This is the description of the first cinema"
                        },
                        new Bookstore()
                        {
                            Name = "Cinema 4",
                            PhotoView = "http://dotnethow.net/images/cinemas/cinema-4.jpeg",
                            Description = "This is the description of the first cinema"
                        }
                    });
                context.SaveChanges();
            }


            //Autors
            if (!context.Autors.Any())
            {
                context.Autors.AddRange(new List<Autor>()
                    {
                        new Autor()
                        {
                            FullName = "AUTOR 1",
                            Bio = "This is the Bio of the first actor",
                            ProfilePictureURL = "http://dotnethow.net/images/actors/actor-1.jpeg"

                        },
                        new Autor()
                        {
                            FullName = "Autor 2",
                            Bio = "This is the Bio of the second actor",
                            ProfilePictureURL = "http://dotnethow.net/images/actors/actor-2.jpeg"
                        },
                        new Autor()
                        {
                            FullName = "Autor 3",
                            Bio = "This is the Bio of the second actor",
                            ProfilePictureURL = "http://dotnethow.net/images/actors/actor-3.jpeg"
                        },
                        new Autor()
                        {

                            FullName = "Autor 4",
                            Bio = "This is the Bio of the second actor",
                            ProfilePictureURL = "http://dotnethow.net/images/actors/actor-5.jpeg"
                            },

                             new Autor()
                        {

                            FullName = "Autor 5",
                            Bio = "This is the Bio of the second actor",
                            ProfilePictureURL = "http://dotnethow.net/images/actors/actor-4.jpeg"
                        },


                    });
                context.SaveChanges();
            }



            //Producers

            if (!context.Producers.Any())
            {
                context.Producers.AddRange(new List<Producer>()
                    {
                        new Producer()
                        {
                            FullName = "Producer 1",
                            Bio = "This is the Bio of the first actor",
                            ProfilePictureURL = "http://dotnethow.net/images/producers/producer-1.jpeg"

                        },
                        new Producer()
                        {
                            FullName = "Producer 2",
                            Bio = "This is the Bio of the second actor",
                            ProfilePictureURL = "http://dotnethow.net/images/producers/producer-2.jpeg"
                        },
                        new Producer()
                        {
                            FullName = "Producer 3",
                            Bio = "This is the Bio of the second actor",
                            ProfilePictureURL = "http://dotnethow.net/images/producers/producer-3.jpeg"
                        },
                        new Producer()
                        {
                            FullName = "Producer 4",
                            Bio = "This is the Bio of the second actor",
                            ProfilePictureURL = "http://dotnethow.net/images/producers/producer-4.jpeg"
                        },
                        new Producer()
                        {
                            FullName = "Producer 5",
                            Bio = "This is the Bio of the second actor",
                            ProfilePictureURL = "http://dotnethow.net/images/producers/producer-5.jpeg"
                        }
                    });
                context.SaveChanges();
            }


            //Booookss
            /*
             {
                 SeedBooks(context);
             }
         }

         static void SeedBooks(AppDbContext context)
         {
             var newBook1 = new Book
             {
                 Name = "The Alchemist",
                 Description = "A novel by Paulo Coelho",
                 Price = 12.99,
                 ImageURL = "http://dotnethow.net/images/movies/movie-1.jpeg",
                 DateActive = DateTime.Now,
                 BooksCategory = BooksCategory.Documentary,
                 BookstoreId = 1, // Replace with existing Bookstore Id
                 ProducerId = 1 // Replace with existing Producer Id
             };
             context.Books.Add(newBook1);

             var newBook2 = new Book
             {
                 Name = "1984",
                 Description = "A novel by George Orwell",
                 Price = 10.50,
                 ImageURL = "http://dotnethow.net/images/movies/movie-3.jpeg",
                 DateActive = DateTime.Now,
                 BooksCategory = BooksCategory.Drama,
                 BookstoreId = 1,
                 ProducerId = 1,
             };
             context.Books.Add(newBook2);

             var newBook3 = new Book
             {
                 Name = "The Lean Startup",
                 Description = "A book by Eric Ries",
                 Price = 19.99,
                 ImageURL = "http://dotnethow.net/images/movies/movie-3.jpeg",
                 DateActive = DateTime.Now,
                 BookstoreId = 3,
                 ProducerId = 3,
                 BooksCategory = BooksCategory.Horror
             };
             context.Books.Add(newBook3);

             context.SaveChanges();
              */


            //me shku te controlleri me shenu njo ka njo qeto t dhanaaa,, amo maspari me i shkru ose me provu ni app inittializier tjeter me qel edhe mi bart qeto edhe ka niher me provu nese bann

            /*


            var books = new List<Book>
    {
        new Book { Name = "Libri 1", Description = "This is the Life movie description",
                            Price = 39.50,
                            ImageURL = "http://dotnethow.net/images/movies/movie-3.jpeg",
                            DateActive = DateTime.Now.AddDays(-10),
                            BooksCategory = BooksCategory.Documentary,
                            BookstoreId = 3,
                            ProducerId = 3,
                            AutorId = 3 },
     
    };
            context.Books.AddRange(books);

            context.SaveChanges();*/




            if (!context.Books.Any())
            {
                context.Books.AddRange(new List<Book>()
                    {
                          new Models.Book
                        {
                            Name = "Liffe",
                            Description = "This is the Life movie description",
                            Price = 39.50,
                            ImageURL = "http://dotnethow.net/images/movies/movie-3.jpeg",
                            DateActive = DateTime.Now.AddDays(-10),
                            BooksCategory = BooksCategory.Documentary,
                            BookstoreId = 3,
                            ProducerId = 3,
                            AutorId = 3,
                        },


                new Models.Book()
                        {
                            Name = "Life",
                            Description = "This is the Life movie description",
                            Price = 34.50,
                            ImageURL = "http://dotnethow.net/images/movies/movie-3.jpeg",
                            DateActive = DateTime.Now.AddDays(-10),
                            BooksCategory = BooksCategory.Documentary,
                            BookstoreId = 3,
                            ProducerId = 3,
                             AutorId = 1,
                         },
                        new Models.Book()
                        {
                            Name = "The Shawshank Redemption",
                            Description = "This is the Shawshank Redemption description",
                            Price = 23.50,
                            ImageURL = "http://dotnethow.net/images/movies/movie-1.jpeg",
                            DateActive = DateTime.Now,
                            BooksCategory = BooksCategory.Documentary,
                            BookstoreId = 1,
                            ProducerId = 1,
                            AutorId = 2
                        },
                        new Models.Book()
                        {
                            Name = "Ghost",
                            Description = "This is the Ghost movie description",
                            Price = 39.50,
                            ImageURL = "http://dotnethow.net/images/movies/movie-4.jpeg",
                            DateActive = DateTime.Now,
                            BooksCategory = BooksCategory.Cartoon,
                            BookstoreId = 4,
                            ProducerId = 4,



                        },
                        new Models.Book()
                        {
                            Name = "Racee",
                            Description = "This is the Race movie description",
                            Price = 49.50,
                            ImageURL = "http://dotnethow.net/images/movies/movie-6.jpeg",
                            DateActive = DateTime.Now,
                            BooksCategory = BooksCategory.Comedy,
                            BookstoreId = 1,
                            ProducerId = 2
                        },
                        new Models.Book()
                        {
                            Name = "Scoob",
                            Description = "This is the Scoob movie description",
                            Price = 39.50,
                            ImageURL = "http://dotnethow.net/images/movies/movie-7.jpeg",
                            DateActive = DateTime.Now,
                            BooksCategory = BooksCategory.Action,
                            BookstoreId = 3,
                            ProducerId = 4
                        },
                        new Models.Book()
                        {
                            Name = "Cold Soles",
                            Description = "This is the Cold Soles movie description",
                            Price = 39.50,
                            ImageURL = "http://dotnethow.net/images/movies/movie-8.jpeg",
                            DateActive = DateTime.Now,
                            BooksCategory = BooksCategory.Horror,
                            BookstoreId = 4,
                            ProducerId = 4
                        }
                    });
                context.SaveChanges();

            }



            //Autors & Movies
            if (!context.Autor_Books.Any())
            {
                context.Autor_Books.AddRange(new List<Autor_Books>()
                    {


                    new Autor_Books()
                    {
                        AutorId = 1,
                        IdBook = 1
                    },
                        new Autor_Books()
                        {
                            AutorId = 3,
                            IdBook = 1
                        },

                         new Autor_Books()
                         {
                             AutorId = 1,
                             IdBook = 2
                         },
                         new Autor_Books()
                         {
                             AutorId = 4,
                             IdBook = 2
                         },

                        new Autor_Books()
                        {
                            AutorId = 1,
                            IdBook = 3
                        },
                        new Autor_Books()
                        {
                            AutorId = 2,
                           IdBook = 3
                        },
                        new Autor_Books()
                        {
                            AutorId = 5,
                            IdBook = 3
                        },


                        new Autor_Books()
                        {
                            AutorId = 2,
                            IdBook = 4
                        },
                        new Autor_Books()
                        {
                            AutorId = 3,
                            IdBook = 4
                        },
                        new Autor_Books()
                        {
                            AutorId = 4,
                            IdBook = 4
                        },


                        new Autor_Books()
                        {
                            AutorId = 2,
                            IdBook = 5
                        },
                        new Autor_Books()
                        {
                            AutorId = 3,
                            IdBook = 5
                        },
                        new Autor_Books()
                        {
                            AutorId = 4,
                            IdBook = 5
                        },
                        new Autor_Books()
                        {
                            AutorId = 5,
                            IdBook = 5
                        },


                        new Autor_Books()
                        {
                            AutorId = 3,
                            IdBook = 6
                        },
                        new Autor_Books()
                        {
                            AutorId = 4,
                            IdBook = 6
                        },
                        new Autor_Books()
                        {
                            AutorId = 5,
                            IdBook = 6
                        },

              });
                context.SaveChanges();
            }
        }

    }


  
}

