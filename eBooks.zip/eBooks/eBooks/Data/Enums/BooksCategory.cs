﻿using System.ComponentModel.DataAnnotations;

namespace eBooks.Data.Enums;

public enum BooksCategory
{
    [Key]
    Action = 1,
    Comedy,
    Drama,
    Documentary,
    Cartoon,
    Horror
}
