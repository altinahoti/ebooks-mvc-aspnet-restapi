﻿using eBooks.Data.Base;
using eBooks.Models;

namespace eBooks.Data.Services
{
    public interface IBookstoresService:IEntityBaseRepository<Bookstore>
    {
    }
}
