﻿using eBooks.Data.Base;
using eBooks.Models;

namespace eBooks.Data.Services
{
    public class BookstoresService:EntityBaseRepository<Bookstore>, IBookstoresService
    {
        public BookstoresService(AppDbContext context) :base(context)
        {
            
        }
    }
}
