﻿using eBooks.Data.Base;
using eBooks.Models;

namespace eBooks.Data.Services
{
    public class ProducersService: EntityBaseRepository<Producer>,IProducersService
    {
        public ProducersService(AppDbContext context) : base(context)
        {
            
        }
    }
}
