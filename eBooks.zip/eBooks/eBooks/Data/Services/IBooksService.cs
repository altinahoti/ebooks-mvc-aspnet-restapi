﻿using eBooks.Data.Base;
using eBooks.Data.ViewModels;
using eBooks.Models;

namespace eBooks.Data.Services
{
    public interface IBooksService:IEntityBaseRepository<Book>
    {
        Task<Book> GetBookByIdAsync(int id);
        Task<NewBookDropdownsVM> GetNewMovieDropdownsValues();

        Task AddNewBookAsync(NewBookVM data);

        Task UpdateBookAsync(NewBookVM data);
    }
}
