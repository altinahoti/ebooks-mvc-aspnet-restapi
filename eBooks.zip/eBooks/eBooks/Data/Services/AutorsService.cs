﻿using eBooks.Data.Base;
using eBooks.Models;
using Microsoft.AspNetCore.Cors.Infrastructure;
using Microsoft.EntityFrameworkCore;

namespace eBooks.Data.Services
{
    public class AutorsService : EntityBaseRepository<Autor>, IAutorsService
    {
        public AutorsService(AppDbContext context) : base(context) { 
        }
    }
}
