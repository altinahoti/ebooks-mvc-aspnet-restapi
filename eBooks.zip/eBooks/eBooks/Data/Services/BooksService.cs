﻿using eBooks.Data.Base;
using eBooks.Data.ViewModels;
using eBooks.Models;
using Microsoft.EntityFrameworkCore;

namespace eBooks.Data.Services
{
    public class BooksService : EntityBaseRepository<Book>, IBooksService
    {
        private readonly AppDbContext _context;
        public BooksService(AppDbContext context) : base(context)

        {
            _context = context;
        }

        public async Task AddNewBookAsync(NewBookVM data)
        {
            var newBook = new Book()
            {
                Name = data.Name,
                Description = data.Description,
                Price = data.Price,
                ImageURL = data.ImageURL,
                DateActive = data.DateActive,
                BookstoreId = data.BookstoreId,
                BooksCategory = data.BooksCategory,
                ProducerId = data.ProducerId,
               

            };
            await _context.Books.AddAsync(newBook);
            await _context.SaveChangesAsync();

            //Add Book Autor
            foreach (var autorId in data.AutorIds)
            {
                var newAutorBook = new Autor_Books()
                {
                    IdBook = newBook.Id,
                    AutorId = autorId
                };
                await _context.Autor_Books.AddAsync(newAutorBook);
            }
            await _context.SaveChangesAsync();
        }


        public async Task<Book> GetBookByIdAsync(int id)
        {
            var bookDetails = await _context.Books
                
                .Include(p => p.Producer)
                .Include(am => am.Autor_Books).ThenInclude(a => a.Autor)
                
                .FirstOrDefaultAsync(n => n.Id == id);

            return bookDetails;
        }


        public async Task<NewBookDropdownsVM> GetNewMovieDropdownsValues()
        {
            

            var response = new NewBookDropdownsVM()
            {

                Autors = await _context.Autors.OrderBy(n => n.FullName).ToListAsync(),
                Bookstores = await _context.Bookstores.OrderBy(n => n.Name).ToListAsync(),
                Producers = await _context.Producers.OrderBy(n => n.FullName).ToListAsync()
            };
            
                return response;
            

        }

        public async Task UpdateBookAsync(NewBookVM data)
        {
            var dbBook = await _context.Books.FirstOrDefaultAsync(n =>n.Id == data.Id);
            if (dbBook != null)
            {

                dbBook.Name = data.Name;
                dbBook.Description = data.Description;
                dbBook.Price = data.Price;
                dbBook.ImageURL = data.ImageURL;
                dbBook.DateActive = data.DateActive;
                dbBook.BookstoreId = data.BookstoreId;
                dbBook.BooksCategory = data.BooksCategory;
                dbBook.ProducerId = data.ProducerId;

                
                await _context.SaveChangesAsync();
            }

            //Remove existing autors

            var existingAutorDb = _context.Autor_Books.Where(n => n.IdBook == data.Id).ToList();

             _context.Autor_Books.RemoveRange(existingAutorDb);
            await _context.SaveChangesAsync();
            //Add Book Autor
            foreach (var autorId in data.AutorIds)
            {
                var newAutorBook = new Autor_Books()
                {
                    IdBook = data.Id,
                    AutorId = autorId
                };
                await _context.Autor_Books.AddAsync(newAutorBook);
            }
            await _context.SaveChangesAsync();
        }
    }
}
