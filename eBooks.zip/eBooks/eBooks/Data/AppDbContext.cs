﻿using eBooks.Models;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace eBooks.Data
{
    public class AppDbContext : IdentityDbContext
    { 
        public AppDbContext(DbContextOptions<AppDbContext> options) :base(options)
        {
            
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)

        {
            modelBuilder.Entity<Book>()
        .Ignore(b => b.Books);


            modelBuilder.Entity<Autor_Books>().HasKey(ab => new { ab.AutorId, ab.IdBook});

            //modelBuilder.Entity<Autor_Books>().HasOne(ab => ab.Autor).WithMany(a => a.AutorBooks).HasForeignKey(ab => ab.AutorId);

            modelBuilder.Entity<Autor_Books>().HasOne(ab => ab.Book).WithMany(b => b.Autor_Books).HasForeignKey(ab => ab.IdBook);



            base.OnModelCreating(modelBuilder);
        }
        public DbSet<Autor> Autors { get; set; }
        public DbSet<Book> Books { get; set; }
        public DbSet<Autor_Books> Autor_Books { get; set; }
        public DbSet<Bookstore> Bookstores{ get; set; }
        public DbSet<Producer> Producers{ get; set; }
       

        //Orders related tables
        public DbSet<Order> Orders { get; set; }
        public DbSet<OrderItem> OrderItems { get; set; }
        public DbSet<ShoppingCartItem> ShoppingCartItems { get; set; }
    }
}
