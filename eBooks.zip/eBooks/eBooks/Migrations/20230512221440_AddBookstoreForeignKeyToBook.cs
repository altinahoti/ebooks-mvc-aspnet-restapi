﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace eBooks.Migrations
{
    /// <inheritdoc />
    public partial class AddBookstoreForeignKeyToBook : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
    name: "BookstoreId",
    table: "Books",
    nullable: false,
    defaultValue: 0);

            migrationBuilder.CreateIndex(
                name: "IX_Books_BookstoreId",
                table: "Books",
                column: "BookstoreId");

            migrationBuilder.AddForeignKey(
                name: "FK_Books_Bookstores_BookstoreId",
                table: "Books",
                column: "BookstoreId",
                principalTable: "Bookstores",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
