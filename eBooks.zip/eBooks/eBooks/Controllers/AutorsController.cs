﻿using eBooks.Data.Services;
using eBooks.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace eBooks.Controllers
{
    //[Authorize(Roles = UserRoles.Admin)]
    public class AutorsController : Controller

    {
        private readonly IAutorsService _service;

        public AutorsController(IAutorsService service)
        {
            _service = service;
        }

        [AllowAnonymous]
        public async Task<IActionResult> Index()
        {
            var data = await _service.GetAllAsync();
            return View(data);
        }

        //Get: Actors/Create
        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create([Bind("FullName,ProfilePictureURL,Bio")] Autor autor)
        {
            if (ModelState.IsValid)
            {
                return View(autor);
            }
            await _service.AddAsync(autor);
            return RedirectToAction(nameof(Index));
        }

        //Get: Autor/Details/1
        [AllowAnonymous]
        public async Task<IActionResult> Details(int id)
        {
            var autorDetails = await _service.GetByIdAsync(id);

            if (autorDetails == null) return View("NotFound");
            return View(autorDetails);
        }

        //Get: Autor/Edit/1
        public async Task<IActionResult> Edit(int id)
        {
            var autorDetails = await _service.GetByIdAsync(id);
            if (autorDetails == null) return View("NotFound");
            return View(autorDetails);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, [Bind("Id,FullName,ProfilePictureURL,Bio")] Autor autor)
        {
            if (ModelState.IsValid)
            {
                return View(autor);
            }

            try
            {
                await _service.UpdateAsync(id, autor);
                return RedirectToAction(nameof(Index));
            }
            catch (DbUpdateConcurrencyException)
            {
                var entity = await _service.GetByIdAsync(id);
                if (entity == null)
                {
                    return View("NotFound");
                }

                ModelState.AddModelError(string.Empty, "The record you attempted to edit was modified by another user after you got the original value.");
                return View(entity);
            }
        } 

        //Get: Autor/Delete/1
        public async Task<IActionResult> Delete(int id)
        {
            var autorDetails = await _service.GetByIdAsync(id);
            if (autorDetails == null) return View("NotFound");
            return View(autorDetails);
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var autorDetails = await _service.GetByIdAsync(id);
            if (autorDetails == null) return View("NotFound");

            await _service.DeleteAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}
