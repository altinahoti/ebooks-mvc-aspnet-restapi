﻿using eBooks.Data;
using eBooks.Data.Services;
using eBooks.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Runtime.CompilerServices;

namespace eBooks.Controllers
{
    //[Authorize(Roles = UserRoles.Admin)]
    public class BooksController : Controller
    {
        private readonly IBooksService _service;

        public BooksController(IBooksService service)
        {
            _service = service;
        }

        public async Task<IActionResult> Index()
        {
            var allBooks = await _service.GetAllAsync();
            return View(allBooks);
        }

        public async Task<IActionResult> Filter(string searchString)
        {
            var allBooks = await _service.GetAllAsync();

            if (!string.IsNullOrEmpty(searchString))
            {
                var filteredResult = allBooks.Where(n => n.Name.Contains(searchString) || n.Description.Contains(searchString)).ToList();

                return View("Index" , filteredResult);
            }



            return View("Index", allBooks);
        } 


        //Get: Books/Details/1

        public async Task<IActionResult> Details(int id)
        {
            var bookDetail = await _service.GetBookByIdAsync(id);
            return View(bookDetail);
        }
        //Get: Books/Create

        public async Task<IActionResult> Create()
        {
            var bookDropdownsData = await _service.GetNewMovieDropdownsValues();

            ViewBag.Bookstores = new SelectList(bookDropdownsData.Bookstores, "Id", "Name");
            ViewBag.Producers = new SelectList(bookDropdownsData.Producers, "Id", "FullName");
            ViewBag.Autors = new SelectList(bookDropdownsData.Autors, "Id", "FullName");

            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Create(NewBookVM book)
        {
            if (!ModelState.IsValid)
            {
                var bookDropdownsData = await _service.GetNewMovieDropdownsValues();

                ViewBag.Bookstores = new SelectList(bookDropdownsData.Bookstores, "Id", "Name");
                ViewBag.Producers = new SelectList(bookDropdownsData.Producers, "Id", "FullName");
                ViewBag.Autors = new SelectList(bookDropdownsData.Autors, "Id", "FullName");

                return View(book);
            }
            await _service.AddNewBookAsync(book);
            return RedirectToAction(nameof(Index));
        }


        //Get: Books/Edit/1

        public async Task<IActionResult> Edit(int id)
        { 
            var bookDetails = await _service.GetBookByIdAsync(id);
            if (bookDetails == null) return View("Not Found");

            var response = new NewBookVM()
            {
                Id = bookDetails.Id,
                Name = bookDetails.Name,
                Description = bookDetails.Description,
                Price = bookDetails.Price,
                DateActive = bookDetails.DateActive,
                ImageURL = bookDetails.ImageURL,
                BooksCategory = bookDetails.BooksCategory,
                BookstoreId = bookDetails.BookstoreId,
                ProducerId = bookDetails.ProducerId,
                AutorIds = bookDetails.Autor_Books.Select(n => n.AutorId).ToList(),
            };
        
            var bookDropdownsData = await _service.GetNewMovieDropdownsValues();

            ViewBag.Bookstores = new SelectList(bookDropdownsData.Bookstores, "Id", "Name");
            ViewBag.Producers = new SelectList(bookDropdownsData.Producers, "Id", "FullName");
            ViewBag.Autors = new SelectList(bookDropdownsData.Autors, "Id", "FullName");

            return View(response);
        }

        [HttpPost]
        public async Task<IActionResult> Edit(int id, NewBookVM book)
        {
            if (id != book.Id) return View("Not Found");

            if (!ModelState.IsValid)
            {
                var bookDropdownsData = await _service.GetNewMovieDropdownsValues();

                ViewBag.Bookstores = new SelectList(bookDropdownsData.Bookstores, "Id", "Name");
                ViewBag.Producers = new SelectList(bookDropdownsData.Producers, "Id", "FullName");
                ViewBag.Autors = new SelectList(bookDropdownsData.Autors, "Id", "FullName");

                return View(book);
            }
            await _service.UpdateBookAsync(book);
            return RedirectToAction(nameof(Index));
        }
    }

}

//n => n.Books