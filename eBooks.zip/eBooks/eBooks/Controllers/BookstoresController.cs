﻿using eBooks.Data;
using eBooks.Data.Services;
using eBooks.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace eBooks.Controllers
{
    //[Authorize(Roles = UserRoles.Admin)]
    public class BookstoresController : Controller
    {
        private readonly IBookstoresService _service;

        public BookstoresController(IBookstoresService service)
        {
            _service = service;
        }

        public async Task<IActionResult> Index()
        {
            var allBookstores = await _service.GetAllAsync();
            return View(allBookstores);
        }
        //Get Bookstores/Create

        public IActionResult Create()
        {
            return View();
        }

        [HttpPost]

        public async Task<IActionResult> Create([Bind("PhotoView,Name,Description")]Bookstore bookstore)
        {
            if(!ModelState.IsValid) return View(bookstore);
            await _service.AddAsync(bookstore);
            return RedirectToAction(nameof(Index));
        }
        //Get:Bookstores/Details/1

        public async Task<IActionResult> Details(int id)
        {
            var bookstoresDetails = await _service.GetByIdAsync(id);
            if (bookstoresDetails == null) return View("Not Found");
            
            return View(bookstoresDetails);

        }
        //Get: Bookstores/Edit/1
        public async Task<IActionResult> Edit(int id)
        {
            var bookstoresDetails = await _service.GetByIdAsync(id);
            if (bookstoresDetails == null) return View("Not Found");

            return View(bookstoresDetails);

        }

        [HttpPost]

        public async Task<IActionResult> Edit(int id,[Bind("Id,PhotoView,Name,Description")] Bookstore bookstore)
        {
            if (!ModelState.IsValid) return View(bookstore);
            await _service.UpdateAsync(id,bookstore);
            return RedirectToAction(nameof(Index));
        }
        //Get: Bookstores/Delete/1
        public async Task<IActionResult> Delete(int id)
        {
            var bookstoresDetails = await _service.GetByIdAsync(id);
            if (bookstoresDetails == null) return View("Not Found");

            return View(bookstoresDetails);

        }

        [HttpPost, ActionName("Delete")]

        public async Task<IActionResult> DeleteConfirm(int id)
        {
            var bookstoresDetails = await _service.GetByIdAsync(id);
            if (bookstoresDetails == null) return View("Not Found");

            
            await _service.DeleteAsync(id);
            return RedirectToAction(nameof(Index));
        }
    }
}


  

