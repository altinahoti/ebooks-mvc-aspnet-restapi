﻿using eBooks.Data.Base;
using eBooks.Data.Enums;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace eBooks.Models
{
    public class Book:IEntityBase
    {
      
        [Key]
        public int Id { get; set; }

       
        public string Name { get; set; }
        public string Description { get; set; }
        public double Price { get; set; }
        public string ImageURL { get; set; }

        public int AutorId { get; set; }
       
      
        public DateTime DateActive { get; set; }

        public BooksCategory BooksCategory { get; set; }

        //Relationships

        public List<Autor_Books> Autor_Books { get; set; }



        //BookStore
        public int BookstoreId { get; set; }

        [ForeignKey("BookstoreId")]
        public Bookstore Bookstore { get; set; }  


        //Producer
        public int ProducerId { get; set; }

        [ForeignKey("ProducerId")]

        public Producer Producer { get; set; }





        public object Books { get; internal set; }
       
    }
}
