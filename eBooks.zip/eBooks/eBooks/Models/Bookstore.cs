﻿using eBooks.Data.Base;
using System.ComponentModel.DataAnnotations;

namespace eBooks.Models
{
    public class Bookstore:IEntityBase
    {
        [Key]
        public int Id { get; set; }

        [Display (Name = "Photo View for Bookstore")]
        [Required(ErrorMessage ="Bookstore is required")]
        public string PhotoView{ get; set; }



        [Display(Name = "Name of Bookstore")]
        [Required(ErrorMessage = "Bookstore Name is required")]
        public string Name { get; set; }


        [Display(Name = "Description")]
        [Required(ErrorMessage = "Description is required")]
        public string Description { get; set; }

        //Relationships

       

        public List<Book> Books { get; set; }

    }
}
