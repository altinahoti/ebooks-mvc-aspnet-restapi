﻿using eBooks.Models;

namespace eBooks.Models
{
    public class Autor_Books
    {

        public int IdBook { get; set; }
        public Book? Book { get; set; }

        public int AutorId { get; set; }
        public Autor Autor { get; set; }
    }
}
        